"use client";
import React from "react";

const Clientcomp = () => {
  return <></>;
};

export default Clientcomp;
